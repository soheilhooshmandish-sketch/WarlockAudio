#include "PluginProcessor.h"
#include "PluginEditor.h"
#include "BinaryData.h"
#include <cmath>

WarlockAudioProcessor::WarlockAudioProcessor()
    : AudioProcessor (BusesProperties()
                          .withInput  ("Input",  juce::AudioChannelSet::stereo(), true)
                          .withOutput ("Output", juce::AudioChannelSet::stereo(), true)),
      apvts (*this, nullptr, "Parameters", createParameterLayout())
{
    oversampler = std::make_unique<juce::dsp::Oversampling<float>> (
        2, 2, juce::dsp::Oversampling<float>::filterHalfBandPolyphaseAllpass, true, true);
}

WarlockAudioProcessor::~WarlockAudioProcessor() {}

juce::AudioProcessorValueTreeState::ParameterLayout WarlockAudioProcessor::createParameterLayout()
{
    juce::AudioProcessorValueTreeState::ParameterLayout layout;

    layout.add (std::make_unique<juce::AudioParameterFloat> (
        juce::ParameterID (PARAM_TRIM_ID, 1), PARAM_TRIM_NAME,
        juce::NormalisableRange<float> (-18.0f, 18.0f, 0.1f, 1.0f), 0.0f));

    layout.add (std::make_unique<juce::AudioParameterFloat> (
        juce::ParameterID (PARAM_GAIN_ID, 1), PARAM_GAIN_NAME,
        juce::NormalisableRange<float> (0.0f, 50.0f, 0.1f, 0.5f), 40.0f));

    layout.add (std::make_unique<juce::AudioParameterFloat> (
        juce::ParameterID (PARAM_COLD_ID, 1), PARAM_COLD_NAME,
        juce::NormalisableRange<float> (-12.0f, 15.0f, 0.1f, 1.0f), 12.0f));

    layout.add (std::make_unique<juce::AudioParameterFloat> (
        juce::ParameterID (PARAM_GRIM_ID, 1), PARAM_GRIM_NAME,
        juce::NormalisableRange<float> (-15.0f, 15.0f, 0.1f, 1.0f), 10.0f));

    layout.add (std::make_unique<juce::AudioParameterFloat> (
        juce::ParameterID (PARAM_GATE_ID, 1), PARAM_GATE_NAME,
        juce::NormalisableRange<float> (-100.0f, -20.0f, 0.5f, 1.0f), -70.0f));

    layout.add (std::make_unique<juce::AudioParameterFloat> (
        juce::ParameterID (PARAM_GATERELEASE_ID, 1), PARAM_GATERELEASE_NAME,
        juce::NormalisableRange<float> (5.0f, 200.0f, 1.0f, 0.5f), 30.0f));

    layout.add (std::make_unique<juce::AudioParameterBool> (
        juce::ParameterID (PARAM_DIODE_ID, 1), PARAM_DIODE_NAME, false));

    layout.add (std::make_unique<juce::AudioParameterBool> (
        juce::ParameterID (PARAM_CAB_ID, 1), PARAM_CAB_NAME, true));

    layout.add (std::make_unique<juce::AudioParameterBool> (
        juce::ParameterID (PARAM_LOFI_ID, 1), PARAM_LOFI_NAME, false));

    layout.add (std::make_unique<juce::AudioParameterFloat> (
        juce::ParameterID (PARAM_LEVEL_ID, 1), PARAM_LEVEL_NAME,
        juce::NormalisableRange<float> (-24.0f, 6.0f, 0.1f, 1.0f), 0.0f));

    layout.add (std::make_unique<juce::AudioParameterBool> (
        juce::ParameterID (PARAM_BYPASS_ID, 1), PARAM_BYPASS_NAME, false));

    return layout;
}

void WarlockAudioProcessor::prepareToPlay (double sampleRate, int samplesPerBlock)
{
    currentSampleRate = sampleRate;
    const int channels = juce::jmax (1, getTotalNumOutputChannels());

    oversampler = std::make_unique<juce::dsp::Oversampling<float>> (
        (size_t) channels, 2,
        juce::dsp::Oversampling<float>::filterHalfBandPolyphaseAllpass, true, true);

    juce::dsp::ProcessSpec spec { sampleRate, (juce::uint32) samplesPerBlock, (juce::uint32) channels };
    oversampler->initProcessing ((size_t) samplesPerBlock);
    setLatencySamples ((int) oversampler->getLatencyInSamples());

    auto resize = [channels] (auto& v)
    {
        v.clear();
        v.resize ((size_t) channels);
        for (auto& f : v)
            f.reset();
    };

    resize (preFilters);
    resize (postFiltersFixed);
    resize (postFiltersMid);
    resize (postFiltersHigh);
    resize (lofiFilters);
    envelopeStates.assign ((size_t) channels, 0.0f);

    lastCold = lastGrim = 1.0e9f;
    lastLofi = lastCab = -1.0f;
    updateToneCoeffs();

    cabinetConvolution.reset();
    // 256-sample / 48 kHz speaker IR (min-phase, ~5 ms). Trim leading zeros.
    // Do not normalise — the mid scoop is the cab. Stereo::yes copies mono → L/R.
    cabinetConvolution.prepare (spec);
    cabinetConvolution.loadImpulseResponse (
        BinaryData::CabinetIR_wav,
        (size_t) BinaryData::CabinetIR_wavSize,
        juce::dsp::Convolution::Stereo::yes,
        juce::dsp::Convolution::Trim::yes,
        0,
        juce::dsp::Convolution::Normalise::no);
    cabReady = true;
}

void WarlockAudioProcessor::releaseResources()
{
    oversampler->reset();
}

bool WarlockAudioProcessor::isBusesLayoutSupported (const BusesLayout& layouts) const
{
    if (layouts.getMainOutputChannelSet() != juce::AudioChannelSet::mono()
        && layouts.getMainOutputChannelSet() != juce::AudioChannelSet::stereo())
        return false;

    if (layouts.getMainOutputChannelSet() != layouts.getMainInputChannelSet())
        return false;

    return true;
}

void WarlockAudioProcessor::updateToneCoeffs()
{
    const float coldDb = apvts.getRawParameterValue (PARAM_COLD_ID)->load();
    const float grimDb = apvts.getRawParameterValue (PARAM_GRIM_ID)->load();
    const bool lofi = apvts.getRawParameterValue (PARAM_LOFI_ID)->load() > 0.5f;
    const double osRate = currentSampleRate * (double) oversampler->getOversamplingFactor();

    if (std::abs (coldDb - lastCold) < 0.05f
        && std::abs (grimDb - lastGrim) < 0.05f
        && (lofi ? 1.0f : 0.0f) == lastLofi)
        return;

    lastCold = coldDb;
    lastGrim = grimDb;
    lastLofi = lofi ? 1.0f : 0.0f;

    auto hp = juce::dsp::IIR::Coefficients<float>::makeHighPass (osRate, 320.0f, 0.707f);
    auto fix = juce::dsp::IIR::Coefficients<float>::makePeakFilter (osRate, 1200.0f, 3.0f, juce::Decibels::decibelsToGain (14.0f));
    auto mid = juce::dsp::IIR::Coefficients<float>::makePeakFilter (osRate, 950.0f, 2.2f, juce::Decibels::decibelsToGain (grimDb));
    auto hi  = juce::dsp::IIR::Coefficients<float>::makePeakFilter (osRate, 4100.0f, 1.8f, juce::Decibels::decibelsToGain (coldDb));
    auto lp  = juce::dsp::IIR::Coefficients<float>::makeLowPass (currentSampleRate, lofi ? 4200.0f : 18000.0f, 0.7f);

    for (auto& f : preFilters)        f.coefficients = hp;
    for (auto& f : postFiltersFixed)  f.coefficients = fix;
    for (auto& f : postFiltersMid)    f.coefficients = mid;
    for (auto& f : postFiltersHigh)   f.coefficients = hi;
    for (auto& f : lofiFilters)       f.coefficients = lp;
}

void WarlockAudioProcessor::processBlock (juce::AudioBuffer<float>& buffer, juce::MidiBuffer&)
{
    juce::ScopedNoDenormals noDenormals;
    const int numCh = buffer.getNumChannels();
    const int numSamples = buffer.getNumSamples();

    for (int i = getTotalNumInputChannels(); i < getTotalNumOutputChannels(); ++i)
        buffer.clear (i, 0, numSamples);

    if (apvts.getRawParameterValue (PARAM_BYPASS_ID)->load() >= 0.5f)
    {
        meterPeak.store (buffer.getMagnitude (0, numSamples));
        return;
    }

    const float trimDb   = apvts.getRawParameterValue (PARAM_TRIM_ID)->load();
    const float gainDb   = apvts.getRawParameterValue (PARAM_GAIN_ID)->load();
    const float gateDb   = apvts.getRawParameterValue (PARAM_GATE_ID)->load();
    const float relMs    = apvts.getRawParameterValue (PARAM_GATERELEASE_ID)->load();
    const bool  useAsym  = apvts.getRawParameterValue (PARAM_DIODE_ID)->load() > 0.5f;
    const bool  runCab   = apvts.getRawParameterValue (PARAM_CAB_ID)->load() > 0.5f;
    const float levelDb  = apvts.getRawParameterValue (PARAM_LEVEL_ID)->load();

    updateToneCoeffs();

    const float trimLin  = juce::Decibels::decibelsToGain (trimDb);
    const float inputGain = juce::Decibels::decibelsToGain (gainDb);
    const float thresh    = juce::Decibels::decibelsToGain (gateDb);
    const float finalLevel = juce::Decibels::decibelsToGain (levelDb);
    const float attackCoef = 1.0f - std::exp (-1.0f / (float) (currentSampleRate * 0.001));
    const float releaseCoef = 1.0f - std::exp (-1.0f / (float) (currentSampleRate * (relMs * 0.001)));

    while ((int) envelopeStates.size() < numCh)
        envelopeStates.push_back (0.0f);

    // 1. Input trim + noise gate (1 ms attack, 8:1 expander)
    for (int ch = 0; ch < numCh; ++ch)
    {
        float* data = buffer.getWritePointer (ch);
        float env = envelopeStates[(size_t) ch];
        for (int i = 0; i < numSamples; ++i)
        {
            float x = data[i] * trimLin;
            const float mag = std::abs (x);
            if (mag > env) env += attackCoef * (mag - env);
            else           env += releaseCoef * (mag - env);
            const float over = env / juce::jmax (thresh, 1.0e-8f);
            const float g = over >= 1.0f ? 1.0f : over * over * over * over;
            data[i] = x * g;
        }
        envelopeStates[(size_t) ch] = env;
    }

    // 2. 4× oversampled diode + tone stack
    juce::dsp::AudioBlock<float> block (buffer);
    auto osBlock = oversampler->processSamplesUp (block);
    const int osN = (int) osBlock.getNumSamples();
    const int osCh = (int) osBlock.getNumChannels();

    while ((int) preFilters.size() < osCh)
    {
        preFilters.emplace_back();
        postFiltersFixed.emplace_back();
        postFiltersMid.emplace_back();
        postFiltersHigh.emplace_back();
        lastCold = 1.0e9f;
        updateToneCoeffs();
    }

    for (int ch = 0; ch < osCh; ++ch)
    {
        auto* channelData = osBlock.getChannelPointer ((size_t) ch);
        auto& preFilt  = preFilters[(size_t) ch];
        auto& posFixed = postFiltersFixed[(size_t) ch];
        auto& posMid   = postFiltersMid[(size_t) ch];
        auto& posHigh  = postFiltersHigh[(size_t) ch];

        for (int sample = 0; sample < osN; ++sample)
        {
            float x = preFilt.processSample (channelData[sample]) * inputGain;

            if (useAsym)
            {
                if (x > 0.35f) x = 0.35f;
                else if (x < -0.75f) x = -0.75f;
            }
            else
            {
                if (x > 0.65f) x = 0.65f;
                else if (x < -0.65f) x = -0.65f;
            }

            x = posFixed.processSample (x);
            x = posMid.processSample (x);
            channelData[sample] = posHigh.processSample (x);
        }
    }

    oversampler->processSamplesDown (block);

    // 3. Lo-Fi LP
    while ((int) lofiFilters.size() < numCh)
    {
        lofiFilters.emplace_back();
        lastLofi = -1.0f;
        updateToneCoeffs();
    }

    for (int ch = 0; ch < numCh; ++ch)
    {
        auto* data = buffer.getWritePointer (ch);
        auto& lp = lofiFilters[(size_t) ch];
        for (int i = 0; i < numSamples; ++i)
            data[i] = lp.processSample (data[i]);
    }

    // 4. Cabinet IR (only when engaged)
    if (runCab && cabReady)
    {
        juce::dsp::AudioBlock<float> cabBlock (buffer);
        juce::dsp::ProcessContextReplacing<float> context (cabBlock);
        cabinetConvolution.process (context);
    }

    buffer.applyGain (finalLevel);
    meterPeak.store (buffer.getMagnitude (0, numSamples));
}

juce::AudioProcessorParameter* WarlockAudioProcessor::getBypassParameter() const
{
    return apvts.getParameter (PARAM_BYPASS_ID);
}

double WarlockAudioProcessor::getTailLengthSeconds() const
{
    if (apvts.getRawParameterValue (PARAM_CAB_ID)->load() > 0.5f)
        return 0.006;
    return 0.0;
}

juce::AudioProcessorEditor* WarlockAudioProcessor::createEditor()
{
    return new WarlockAudioProcessorEditor (*this);
}

void WarlockAudioProcessor::getStateInformation (juce::MemoryBlock& destData)
{
    auto state = apvts.copyState();
    std::unique_ptr<juce::XmlElement> xml (state.createXml());
    copyXmlToBinary (*xml, destData);
}

void WarlockAudioProcessor::setStateInformation (const void* data, int sizeInBytes)
{
    std::unique_ptr<juce::XmlElement> xmlState (getXmlFromBinary (data, sizeInBytes));
    if (xmlState.get() != nullptr && xmlState->hasTagName (apvts.state.getType()))
        apvts.replaceState (juce::ValueTree::fromXml (*xmlState));
}

juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter()
{
    return new WarlockAudioProcessor();
}
