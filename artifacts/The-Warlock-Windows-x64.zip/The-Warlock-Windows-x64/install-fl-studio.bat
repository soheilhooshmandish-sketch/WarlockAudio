@echo off
cd /d "%~dp0"
echo Launching The Warlock Setup (auto install)...
if exist "%~dp0Setup.exe" (
  "%~dp0Setup.exe"
) else (
  echo Setup.exe missing. Unzip the whole Windows pack first.
  pause
)
