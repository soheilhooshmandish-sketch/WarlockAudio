#pragma once
#include <algorithm>
#include <cmath>
#include <cstdint>

// Exact port of src/lib/audio/dsp.ts — distortSample / makeBoostCurve / makeAmpCurve.
namespace DistDSP
{
enum class DistMode : int
{
    RAW = 0,
    FROST,
    CHAINSAW,
    NECRO,
    INFERNO,
    FUZZ_ABYSS,
    BLAST,
    kNumModes
};

inline constexpr const char* kModeNames[] = {
    "RAW", "FROST", "CHAINSAW", "NECRO", "INFERNO", "FUZZ_ABYSS", "BLAST"};

inline float clamp1 (float v) noexcept
{
    return std::max (-1.0f, std::min (1.0f, v));
}

inline float sgn (float v) noexcept
{
    return (v > 0.0f) - (v < 0.0f);
}

/** dsp.ts distortSample(x, a, mode) — bit-identical math. */
inline float distortSample (float x, float a, DistMode mode) noexcept
{
    a = std::max (0.02f, a);
    switch (mode)
    {
        case DistMode::RAW:
        {
            const float g = 1.0f + a * 10.0f;
            const float y = std::tanh (x * g);
            const float asym = x < 0.0f ? x * 0.18f * a : 0.0f;
            return clamp1 (y * 0.92f + asym);
        }
        case DistMode::FROST:
        {
            const float g = 1.0f + a * 16.0f;
            float y = std::tanh (x * g * 1.35f);
            y += 0.07f * a * std::sin (y * 3.14159265358979323846f * 3.0f);
            return clamp1 (y * 1.02f);
        }
        case DistMode::CHAINSAW:
        {
            const float g = 1.0f + a * 20.0f;
            float y = std::tanh (x * g * 1.25f);
            y = sgn (y) * std::pow (std::abs (y), 0.62f);
            return clamp1 (y * 0.94f);
        }
        case DistMode::NECRO:
        {
            const float g = 1.0f + a * 7.0f;
            const float y = std::atan (x * g) / std::atan (g);
            const float wrinkle = 0.04f * a * std::sin (x * 17.3f);
            return clamp1 (y * 0.9f + wrinkle);
        }
        case DistMode::INFERNO:
        {
            const float g = 1.0f + a * 26.0f;
            return clamp1 (std::tanh (x * g) * 0.88f);
        }
        case DistMode::FUZZ_ABYSS:
        {
            const float g = 1.0f + a * 36.0f;
            float y = x * g;
            y = y >= 0.0f ? 1.0f - std::exp (-y) : -1.0f + std::exp (y);
            y = std::tanh (y * 2.2f);
            if (std::abs (y) > 0.82f)
                y = sgn (y) * (0.82f - (std::abs (y) - 0.82f) * 0.45f);
            return clamp1 (y);
        }
        case DistMode::BLAST:
        {
            const float g = 1.0f + a * 18.0f;
            return clamp1 (std::tanh (x * g * 1.55f) * 0.86f);
        }
        default:
            return clamp1 (std::tanh (x * (1.0f + a * 12.0f)));
    }
}

/** dsp.ts makeBoostCurve inner: tanh(x*g)/tanh(g), g = 1 + drive*4 */
inline float boostSample (float x, float drive) noexcept
{
    const float g = 1.0f + drive * 4.0f;
    const float d = std::tanh (g);
    if (d == 0.0f) return 0.0f;
    return std::tanh (x * g) / d;
}

/** dsp.ts makeAmpCurve inner: tanh(x*g)*0.9 + 0.08*tanh(x*g*3), g = 1 + gain*14 */
inline float ampSample (float x, float gain) noexcept
{
    const float g = 1.0f + gain * 14.0f;
    const float y = std::tanh (x * g) * 0.9f + 0.08f * std::tanh (x * g * 3.0f);
    return clamp1 (y);
}

inline DistMode modeFromIndex (int i) noexcept
{
    i = std::clamp (i, 0, (int) DistMode::kNumModes - 1);
    return static_cast<DistMode> (i);
}
} // namespace DistDSP
