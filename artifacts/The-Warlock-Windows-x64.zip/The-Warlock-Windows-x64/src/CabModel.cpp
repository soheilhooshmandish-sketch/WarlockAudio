#include "CabModel.h"
#include <algorithm>
#include <vector>

namespace
{
const std::vector<Resonance>& table (CabType t)
{
    static const std::vector<Resonance> modern = {
        { 92.f, 0.045f, 0.85f }, { 430.f, 0.018f, 0.38f }, { 1850.f, 0.01f, 0.55f },
        { 3400.f, 0.007f, 0.72f }, { 5600.f, 0.004f, 0.28f }
    };
    static const std::vector<Resonance> vintage = {
        { 78.f, 0.055f, 0.9f }, { 380.f, 0.022f, 0.5f }, { 1400.f, 0.012f, 0.48f },
        { 2800.f, 0.008f, 0.5f }, { 4200.f, 0.005f, 0.18f }
    };
    static const std::vector<Resonance> cold = {
        { 110.f, 0.03f, 0.55f }, { 520.f, 0.014f, 0.28f }, { 2200.f, 0.009f, 0.62f },
        { 4100.f, 0.006f, 0.85f }, { 7200.f, 0.003f, 0.4f }
    };
    static const std::vector<Resonance> atmos = {
        { 120.f, 0.05f, 0.5f }, { 680.f, 0.02f, 0.4f },
        { 2600.f, 0.012f, 0.7f }, { 5400.f, 0.006f, 0.55f }
    };
    static const std::vector<Resonance> raw = {
        { 85.f, 0.06f, 0.7f }, { 350.f, 0.025f, 0.55f }, { 1250.f, 0.014f, 0.6f },
        { 2500.f, 0.01f, 0.45f }, { 3800.f, 0.006f, 0.22f }
    };
    static const std::vector<Resonance> wall = {
        { 70.f, 0.07f, 1.f }, { 240.f, 0.03f, 0.55f }, { 900.f, 0.016f, 0.4f },
        { 2100.f, 0.01f, 0.58f }, { 3800.f, 0.007f, 0.5f }, { 6200.f, 0.004f, 0.22f }
    };
    switch (t)
    {
        case CabType::MODERN_412:  return modern;
        case CabType::VINTAGE_412: return vintage;
        case CabType::COLD_412:    return cold;
        case CabType::ATMOS_212:   return atmos;
        case CabType::RAW_412:     return raw;
        default:                   return wall;
    }
}
} // namespace

void CabModel::prepare (double sampleRate) noexcept
{
    fs = sampleRate > 1.0 ? sampleRate : 44100.0;
    rebuild();
}

void CabModel::setType (CabType t) noexcept
{
    if (t == type) return;
    type = t;
    rebuild();
}

CabType CabModel::typeFromIndex (int i) noexcept
{
    i = std::clamp (i, 0, (int) CabType::kNumCabs - 1);
    return static_cast<CabType> (i);
}

void CabModel::reset() noexcept
{
    for (auto& r : res) { r.z1 = 0; r.z2 = 0; }
}

void CabModel::rebuild() noexcept
{
    const auto& tab = table (type);
    nRes = (int) std::min (tab.size(), res.size());
    const float twoPi = 6.28318530718f;
    for (int i = 0; i < nRes; ++i)
    {
        const float f = tab[(size_t) i].f;
        const float d = std::max (0.0005f, tab[(size_t) i].d);
        const float a = tab[(size_t) i].a;
        const float poleR = std::exp (-1.0f / (d * (float) fs));
        const float w = twoPi * f / (float) fs;
        res[(size_t) i].a1 = 2.0f * poleR * std::cos (w);
        res[(size_t) i].a2 = -poleR * poleR;
        // scale so impulse peak is ~a (matches IR amplitude)
        res[(size_t) i].g = a * (1.0f - poleR);
        res[(size_t) i].z1 = 0;
        res[(size_t) i].z2 = 0;
    }
    for (int i = nRes; i < (int) res.size(); ++i)
        res[(size_t) i] = {};
}

float CabModel::process (float x) noexcept
{
    float acc = 0.0f;
    for (int i = 0; i < nRes; ++i)
        acc += res[(size_t) i].tick (x);
    return x * dryMix + acc * wetMix;
}
