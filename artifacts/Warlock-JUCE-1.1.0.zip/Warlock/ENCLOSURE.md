# Custom stompbox enclosure (Warlock 1510)

Warlock is laid out as a **Hammond 1590XX** die-cast box, not a 125B compact.

| Box | Size (mm) | Fits |
|---|---|---|
| 1590B | 112 × 61 × 31 | 3 knobs + stomp |
| 125B / 1590N1 | 117 × 62 × 32 | 3–4 knobs, top jacks |
| 1590BB | 119 × 94 × 34 | 6 knobs |
| **1590XX** | **145 × 121 × 39** | 6 knobs + stomp + LCD + rockers |

Four M3.5 lid screws at the corners. Powder-coat black. Graphics live **inside the UV keepout** (inside the curved lip — Tayda / Dazatronyx will clip anything on the radius).

## How custom boxes are actually made

1. Pick the casting (Hammond / Tayda clone).
2. **Drill template** — hole Ø and X/Y for pots (7 mm), 3PDT (12 mm), LED (5–8 mm), Neutrik jacks on the top end, 2.1 mm DC.
3. **Powder coat** (matte black here). UV ink does not stick to raw/polished aluminum.
4. **UV print** (full-color seal) or **silkscreen** (1–2 spot colors). Optional gloss varnish.
5. Hardware: nickel 6.35 mm jacks, 2.1 mm DC (negative tip), aluminum 1510 knobs, mushroom 3PDT, rubber feet, ground lug.

Warlock’s UI follows that stack: coat texture, lid seam, wall thickness, keepout, nickel jacks on the short side, 9V − print, ground lug, 4 screws, 1510 knobs, 3PDT in a well.

Do not UV-print to the screw bosses. Do not put art on the 2–3 mm lip.

## VST3

The editor is the same lid: logo in a stamped well, BinaryData chassis/knob/stomp/logo. It is not a drill file. For a physical run, export a 1590XX artboard (lid ~121 × 145 mm) with a 4 mm inner margin.
