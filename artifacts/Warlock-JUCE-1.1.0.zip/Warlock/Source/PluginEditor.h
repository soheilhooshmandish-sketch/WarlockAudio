#pragma once
#include <JuceHeader.h>
#include "PluginProcessor.h"

class PedalLookAndFeel : public juce::LookAndFeel_V4
{
public:
    PedalLookAndFeel();
    void drawRotarySlider (juce::Graphics&, int x, int y, int width, int height,
                           float sliderPos, float rotaryStartAngle, float rotaryEndAngle,
                           juce::Slider&) override;
    void drawToggleButton (juce::Graphics&, juce::ToggleButton&,
                           bool shouldDrawButtonAsHighlighted, bool shouldDrawButtonAsDown) override;

    juce::Image knobImage, stompImage, chassisImage, logoImage;
};

class WarlockAudioProcessorEditor : public juce::AudioProcessorEditor,
                                    private juce::Timer
{
public:
    WarlockAudioProcessorEditor (WarlockAudioProcessor&);
    ~WarlockAudioProcessorEditor() override;

    void paint (juce::Graphics&) override;
    void resized() override;

private:
    void timerCallback() override;

    WarlockAudioProcessor& audioProcessor;
    PedalLookAndFeel lnf;

    juce::Slider gainSlider, coldSlider, grimSlider, gateSlider, releaseSlider, levelSlider, trimSlider;
    juce::ToggleButton diodeButton, cabButton, lofiButton, stompButton;

    using SliderAttachment = juce::AudioProcessorValueTreeState::SliderAttachment;
    using ButtonAttachment = juce::AudioProcessorValueTreeState::ButtonAttachment;

    std::unique_ptr<SliderAttachment> gainAttachment, coldAttachment, grimAttachment,
        gateAttachment, releaseAttachment, levelAttachment, trimAttachment;
    std::unique_ptr<ButtonAttachment> diodeAttachment, cabAttachment, lofiAttachment;

    float ledPulse = 0.0f;
    float meterSmooth = 0.0f;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (WarlockAudioProcessorEditor)
};
