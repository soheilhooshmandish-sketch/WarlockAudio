# Warlock Chainsaw Distortion — JUCE VST3 1.1.0

Nihil Audio. Windows x64. Same DSP as the browser pedal.

| Doc | For |
|---|---|
| [INSTALL.md](INSTALL.md) | Put it in a DAW (screenshots) |
| [ENCLOSURE.md](ENCLOSURE.md) | Hammond 1590XX / UV print keepout |

```
build.bat
```

or

```
cmake --preset vs2022-x64
cmake --build --preset warlock-release
```

Needs git, CMake ≥ 3.22, VS 2022. JUCE 7.0.12 is fetched by CMake.
