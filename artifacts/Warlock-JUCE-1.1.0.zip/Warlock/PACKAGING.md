# VST3 packaging standards (Warlock)

Steinberg VST 3.6.10+ bundle. Two layers:

1. **Inside the DLL** (`juce_add_binary_data`) — chassis, knobs, stomp, IR. The editor never touches disk.
2. **Beside the DLL** (`Contents/Resources`, bundle root) — what a host can read *without* loading code: snapshots, legal, moduleinfo, Explorer icon.

## Windows bundle (what we ship)

```
C:\Program Files\Common Files\VST3\Warlock.vst3\     ← {app}, folder named .vst3
├── desktop.ini                                      ← optional, hidden+system
├── Plugin.ico                                       ← optional, hidden
└── Contents\
    ├── x86_64-win\
    │   └── Warlock.vst3                             ← PE DLL, SAME name as folder
    └── Resources\
        ├── moduleinfo.json                          ← SDK 3.7.8+ path (not Contents/)
        ├── legal.txt
        ├── CabinetIR.wav                            ← also BinaryData
        └── Snapshots\
            ├── {CID}_snapshot.png                   ← Cubase Media Rack 1x
            └── {CID}_snapshot_2.0x.png              ← HiDPI
```

| Spec | Rule | Warlock |
|---|---|---|
| Install root | `Common Files\VST3\` only | installer `{commoncf64}\VST3\Warlock.vst3` |
| Folder = DLL name | `Warlock.vst3` / `x86_64-win/Warlock.vst3` | JUCE artefact |
| Arch folder | `x86_64-win` (not `x64` or `win64`) | JUCE |
| moduleinfo.json | `Contents/Resources/` since 3.7.8 | copy after JUCE generates CID |
| Snapshots | PNG, `{CID32}_snapshot.png` + `_2.0x` | `Resources/Snapshots/` → POST_BUILD |
| Explorer icon | `desktop.ini` + `Plugin.ico`, attrib +s +h | `Resources/windows/` |
| 32-bit | `x86-win` under Program Files (x86) | not shipped |
| ARM | `arm64ec-win` or `arm64x-win` | not shipped; `x64compatible` emulation |
| Single-file `.vst3` DLL | deprecated pre-3.6.10 | do not flatten |

CMake POST_BUILD copies legal, Snapshots, desktop.ini, Plugin.ico into the artefact so Inno’s `recursesubdirs` installs them.

## macOS (not built here)

```
Warlock.vst3/Contents/MacOS/Warlock
Warlock.vst3/Contents/Info.plist
Warlock.vst3/Contents/Resources/moduleinfo.json
```

Install to `~/Library/Audio/Plug-Ins/VST3/` or `/Library/Audio/Plug-Ins/VST3/`.

## What must not happen

- Copying only `Contents/x86_64-win/Warlock.vst3` to the VST3 root — Cubase misses snapshots and some hosts miss the GUI resources.
- Nesting `Nihil Audio\Warlock` under VST3 — scanners skip vendor folders.
- Putting `moduleinfo.json` in `Contents/` (3.7.5 path). 3.7.8+ is `Contents/Resources/` for notarization.
- Inventing a CID for snapshots. Wrong name = silent thumbnail miss.

## Installer

`installer.iss` unpacks the **whole artefact folder** into `{app}`. `{app}` **is** `Warlock.vst3`. Admin, 64-bit, Restart Manager. See [INSTALL.md](INSTALL.md).
